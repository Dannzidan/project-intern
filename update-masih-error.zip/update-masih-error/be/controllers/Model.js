import Model from "../models/Model.js";
import Users from "../models/UserModel.js";
import { Op } from "sequelize";

const modelAttributes = [
    'id',
    'assigned_mod',
    'assigned_sup',
    'uuid',
    'name',
    'createdAt',
    'updatedAt',
    'model_image',
];

export const getModels = async (req, res) => {
    try {
        let response;
        if (req.role === "admin") {
            response = await Model.findAll({
                attributes: modelAttributes,
                include: [
                    {
                        model: Users,
                        attributes: ['name', 'email']
                    }
                ]
            });
        } else {
            response = await Model.findAll({
                attributes: modelAttributes,
                where: req.role == 'moderator' ? {
					[Op.or]: [
					  {
						assigned_mod: {
						  [Op.like]: req.userId+'-%'
						}
					  },
					  {
						userId: req.userId
					  }
					]
                }:{
					[Op.or]: [
					  {
						assigned_sup: {
						  [Op.like]: req.userId+'-%'
						}
					  },
					  {
						userId: req.userId
					  }
					]
                },
                include: [
                    {
                        model: User,
                        attributes: ['name', 'email']
                    }
                ]
            });
        }
        res
            .status(200)
            .json(response);
    } catch (error) {
        res
            .status(500)
            .json({msg: error.message});
    }
};

export const getModelById = async (req, res) => {
    try {
        const model = await Model.findOne({
            attributes: modelAttributes,
            where: {
                uuid: req.params.id
            }
        });
        if(!model)
            return res
                .status(404)
                .json({msg: "Model not found"});
        let response;
        if(req.role == "admin"){
            response = await Model.findOne({
                attributes: modelAttributes,
                where: {
                    id: model.id
                },
                include: [
                    {
                        model: Users,
                        attributes: ['name', 'email']
                    }
                ]
            });
        } else {
            if (req.userId !== model.userId) {
                return res
                    .status(401)
                    .json({msg: "Not authorized"});
            }
            response = await Model.findOne({
                attributes: modelAttributes,
                where: {
                    [Op.and]: [
                        {
                            id: model.id
                        },
                        {
                            userId: req.userId
                        }
                    ]
                },
                include: [
                    {
                        model: Users,
                        attributes: ['name', 'email']
                    }
                ]
            });
        };

        res
            .status(200)
            .json(response);
    } catch (error) {
        res
            .status(500)
            .json({msg: error.message});
    }
};
        
export const createModel = async (req, res) => {
    const { assigned_mod, assigned_sup, name, model_image } = req.body;
    try  {
        await Model.create({
            assigned_mod: assigned_mod,
            assigned_sup: assigned_sup,
            name: name,
            model_image: model_image,
            userId: req.userId
        });
        res
            .status(201)
            .json({msg: "Task Created Successfully"});
    } catch (error) {
        res
            .status(500)
            .json({msg: error.message});
    }
};

export const updateModel = async (req, res) => {
    try {
        const model = await Model.findOne({
            where: {
                uuid: req.params.id
            }
        });
        if (!model) 
            return res
                .status(404)
                .json({msg: "Data not found"});
        const {
            assigned_mod,
            assigned_sup,
            name,
            model_image,
        } = req.body;
        if (req.role ==="admin") {
            await Model.update(
                {
                    assigned_mod,
                    assigned_sup,
                    name,
                    model_image,
                },
                {where: {
                    id: model.id
                }}
            );
        } else {
            if (req.userId !== model.userId) 
                return res
                    .status(401)
                    .json({msg: "Not authorized"});
            await Model.update({
                    assigned_mod,
                    assigned_sup,
                    name,
                    model_image,
                },{
                where: {
                    [Op.and]: [
                        {
                            id: model.id
                        },
                        {
                            userId: req.userId
                        }
                    ]
                }
            });
        }
        res
            .status(200)
            .json({msg: "Model Updated Successfully"});
    } catch (error) {
        res
            .status(500)
            .json({msg: error.message});
    }
}

export const deleteModel = async (req, res) => {
    try {
        const model = await Model.findOne({
            where: {
                uuid: req.params.id
            }
        });
        if (!model) 
            return res
                .status(404)
                .json({msg: "Data not found"});
        const {
            assigned_mod,
            assigned_sup,
            name,
            model_image,
        } = req.body;
        if (req.role ==="admin") {
            await Model.destroy({
                where: {
                    id: model.id
                }
            });
        } else {
            if (req.userId !== model.userId) 
                return res
                    .status(401)
                    .json({msg: "Not authorized"});
            await Model.destroy({
                where: {
                    [Op.and]: [
                        {
                            id: model.id
                        },
                        {
                            userId: req.userId
                        }
                    ]
                }
            });
        }
        res 
            .status(200)
            .json({msg: "Model Deleted Successfully"});
    } catch (error) {
        res 
            .status(500)
            .json({msg: error.message});
    }
};
