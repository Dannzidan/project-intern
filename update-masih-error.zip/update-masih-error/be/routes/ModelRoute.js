import express from 'express';
import {
    getModels,
    getModelById,
    createModel,
    updateModel,
    deleteModel
} from "../controllers/Model.js";

import { verifyUser } from "../middleware/AuthUser.js";

const router = express.Router();

router.get('/models',verifyUser ,getModels );
router.get('/models/:id',verifyUser ,getModelById);
router.post('/models',verifyUser ,createModel);
router.patch('/models/:id',verifyUser ,updateModel);
router.delete('/models/:id',verifyUser ,deleteModel);

export default router;