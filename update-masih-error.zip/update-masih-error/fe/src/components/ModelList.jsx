import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import axios from "axios";
import { useSelector } from "react-redux";

const ModelList = () => {
  const { user } = useSelector((state) => state.auth);
  const [modelList, setModelList] = useState([]);
  const [error, setError] = useState(null);

  useEffect(() => {
    if (user && user.name) {
      getModels();
    }
  }, [user]);

  const getModels = async () => {
    try {
      const token = localStorage.getItem("token");
      let params = "";
      if (user.role === "moderator") {
        params = "?assigned_mod=" + user.id;
      } else if (user.role === "supplier") {
        params = "?assigned_sup=" + user.id;
      }
      const response = await axios({
        url: `${process.env.REACT_APP_BASE_URL}/models`,
        method: "GET",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      });

      setModelList(response.data);
      setError(null);
    } catch (error) {
      setError("Error fetching tasks. Please try again later.");
    }
  };


  const deleteModel = async (taskId) => {
    const confirmed = window.confirm(
      "Are you sure you want to delete this task?"
    );
    if (!confirmed) {
      return;
    }

    try {
      const token = localStorage.getItem("token");
      await axios({
        url: `${process.env.REACT_APP_BASE_URL}/models/${taskId}`,
        method: "DELETE",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      });

      getModels();
      setError(null);
    } catch (error) {
      setError("Error deleting the task. Please try again later.");
    }
  };

  return (
    <div className="tasks-list-container">
      <h1 className="title">Model</h1>
      <h2 className="subtitle">Daftar Model</h2>
      {error && <p className="has-text-danger">{error}</p>}
      {user && user.role !== "supplier" && (
        <Link to="/models/add" className="button is-primary mb-2">
          Tambah Baru
        </Link>
      )}
      <table className="table is-striped is-fullwidth">
        <thead>
          <tr>
            <th>No</th>
            <th>User</th>
            <th>Model Name</th>
            <th>Part Image</th>
            <th>Assigned to PIC</th>
            <th>Assigned to Supplier</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {modelList.map((model, index) => (
            <tr key={model.uuid}>
              <td>{index + 1}</td>
              <td>{model.user && model.user.name}</td>
              <td>{model.name}</td>
              <td>
                {model.model_image && (
                  <img
                    src={model.model_image}
                    alt={`Model Image ${index + 1}`}
                    style={{ maxWidth: "100px", maxHeight: "100px" }}
                  />
                )}
              </td>
              <td>{model.assigned_mod}</td>
              <td>{model.assigned_sup}</td>
              <td>
                {user && user.role !== "supplier" && (
                  <Link
                    to={`/models/edit/${model.uuid}`}
                    className="button is-small is-info is-responsive"
                  >
                    Edit
                  </Link>
                )}
                {user && user.role !== "supplier" && (
                  <button
                    onClick={() => deleteModel(model.uuid)}
                    className="button is-small is-danger is-responsive"
                    style={{ marginRight: "1px", marginLeft: "1px" }}
                  >
                    Delete
                  </button>
                )}
                <Link
                  to={`/models/tasks/${model.id}`}
                  className="button is-small is-link is-responsive"
                >
                  View Tasks
                </Link>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default ModelList;
